import React, { useState, useEffect } from 'react';
import {
  Crosshair, Flame, Shield, Target, Cpu, Tv, Music, Apple,
  MessageSquare, Sparkles, Gamepad2, Gamepad, Box, Search,
  ShoppingCart, ChevronRight, ChevronDown, Info, Lock, Wallet,
  Smartphone, CheckCircle, CreditCard, Award, Landmark, User,
  Check, Image as ImageIcon, MessageCircle, X, Send, Clock, Loader2,
  Facebook, Instagram, Youtube, AlertTriangle, Play, HelpCircle,
  TrendingUp, Globe, FileCheck, Layers, Sparkle, Zap
} from 'lucide-react';

import { PRODUCTS, PAYMENT_METHODS, FAQS } from './data';
import { Product, PaymentMethod, Order, Tier, ProductType } from './types';

import SupportAgent from './components/SupportAgent';
import LiveTransactionFeed from './components/LiveTransactionFeed';
import MyOrdersTracker from './components/MyOrdersTracker';

const iconMap: Record<string, React.ComponentType<any>> = {
  Crosshair, Flame, Shield, Target, Cpu, Tv, Music, Apple,
  MessageSquare, Sparkles, Gamepad2, Gamepad, Box
};

export default function App() {
  // Navigation & Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | ProductType>('all');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Modal / Selection State
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedTier, setSelectedTier] = useState<Tier | null>(null);
  const [targetId, setTargetId] = useState('');
  
  // Checkout State
  const [checkoutProduct, setCheckoutProduct] = useState<Product | null>(null);
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod | null>(null);
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);
  const [checkoutStage, setCheckoutStage] = useState(0);
  const [successfulOrder, setSuccessfulOrder] = useState<Order | null>(null);

  // Persistent Ledger / Local ordersState
  const [orders, setOrders] = useState<Order[]>([]);

  // FAQ state
  const [activeFaqIndex, setActiveFaqIndex] = useState<number | null>(null);

  // Notification Toast state
  const [toasts, setToasts] = useState<Array<{ id: string; message: string; type: 'success' | 'info' | 'warning' | 'error' }>>([]);

  // Load orders on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('gametopup_np_orders_session');
      if (saved) {
        setOrders(JSON.parse(saved));
      }
    } catch (e) {
      console.error("Local storage ledger could not load:", e);
    }
  }, []);

  // Sync orders to localStorage on any state modification
  const saveOrders = (updatedOrders: Order[]) => {
    setOrders(updatedOrders);
    try {
      localStorage.setItem('gametopup_np_orders_session', JSON.stringify(updatedOrders));
    } catch (e) {
      console.error("Local storage save failed:", e);
    }
  };

  const showToast = (message: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    
    // Auto-remove after 4 seconds
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Keyboard escape listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedProduct(null);
        setCheckoutProduct(null);
        setIsSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filter products based on search and category
  const filteredProducts = PRODUCTS.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          product.requires.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.type === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleProductCardClick = (product: Product) => {
    setSelectedProduct(product);
    setSelectedTier(null);
    setTargetId('');
  };

  const handleProceedToCheckout = () => {
    if (!selectedProduct || !selectedTier) return;
    if (!targetId.trim()) {
      showToast(`Please enter a valid ${selectedProduct.requires}`, 'warning');
      return;
    }

    // Capture selections and step into Payment Gateway
    setCheckoutProduct(selectedProduct);
    setSelectedPayment(null);
    setReceiptFile(null);
    setSuccessfulOrder(null);
    
    // Close selection modal
    setSelectedProduct(null);
  };

  const handleTriggerPayment = () => {
    if (!checkoutProduct || !selectedPayment || !selectedTier) return;
    
    // Bank check needs receipt file
    if (selectedPayment.id === 'bank' && !receiptFile) {
      showToast('Please upload your bank transfer deposit screenshot to continue', 'warning');
      return;
    }

    setIsProcessingCheckout(true);
    setCheckoutStage(0);

    // Progression stage interval mapping
    const timer = setInterval(() => {
      setCheckoutStage(prev => {
        if (prev < 4) {
          return prev + 1;
        } else {
          clearInterval(timer);
          // Complete pipeline checkout simulation
          const uniqueOrderId = 'GTP-' + Math.floor(1000 + Math.random() * 9000) + '-' + Date.now().toString(36).substring(3, 8).toUpperCase();
          
          const newOrder: Order = {
            id: uniqueOrderId,
            product: checkoutProduct,
            selectedTier: selectedTier,
            targetId: targetId,
            paymentMethod: selectedPayment,
            status: 'pending', // Starts pending, MyOrdersTracker automatically animates pipeline stages
            createdAt: new Date().toISOString()
          };

          const newLedger = [newOrder, ...orders];
          saveOrders(newLedger);
          setSuccessfulOrder(newOrder);
          setIsProcessingCheckout(false);
          showToast(`⚡ Invoice processed! Check status below.`, 'success');

          // Scroll down to tracker section smoothly
          setTimeout(() => {
            document.getElementById('order-history-section')?.scrollIntoView({ behavior: 'smooth' });
          }, 400);
          
          return 5;
        }
      });
    }, 1200);
  };

  const handleClearOrders = () => {
    saveOrders([]);
    showToast("Session ledger successfully cleared", "info");
  };

  const triggerMockUpload = () => {
    document.getElementById('receipt-screenshot-uploader')?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setReceiptFile(file);
      showToast(`Uploaded: ${file.name} (${Math.round(file.size / 1024)} KB)`, 'success');
    }
  };

  const getToastColors = (type: string) => {
    switch (type) {
      case 'success': return 'bg-emerald-500/10 border-emerald-500/30 text-neon-green';
      case 'warning': return 'bg-amber-500/10 border-amber-500/30 text-amber-400';
      case 'error': return 'bg-rose-500/10 border-rose-500/30 text-rose-400';
      default: return 'bg-cyan-500/10 border-cyan-500/30 text-neon-blue';
    }
  };

  return (
    <div className="bg-[#0f172a] text-slate-50 min-h-screen font-sans antialiased relative overflow-x-hidden selection:bg-red-600 selection:text-white pb-12">
      
      {/* SCANLINE OVERLAY EFFECT */}
      <div className="fixed inset-0 pointer-events-none z-[50] opacity-[0.01] bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,0,0,0.3)_2px,rgba(0,0,0,0.3)_4px)]"></div>

      {/* DOCK TOP STATUS ANNOUNCEMENT */}
      <div className="bg-[#090d1a] border-b-2 border-slate-800 sticky top-0 z-[100] backdrop-blur-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
            </span>
            <span className="text-red-500 font-display font-black text-[11px] sm:text-xs tracking-wider uppercase">
              LIVE AUTOMATED WEBHOOK STATUS: OPERATIONAL 24/7 — INSTANT DISPATCH
            </span>
          </div>
          <div className="hidden md:flex items-center gap-5 text-[11px] text-slate-500 font-mono tracking-wider font-bold">
            <span className="flex items-center gap-1.5"><Lock className="w-3 h-3 text-emerald-400" /> SSL SECURED</span>
            <span className="flex items-center gap-1.5 text-emerald-400"><Clock className="w-3 h-3 animate-pulse" /> AVG DISPATCH: 15 SECS</span>
          </div>
        </div>
      </div>

      {/* FLOATING NOTIFICATION TOAST WRAPPER */}
      <div className="fixed bottom-6 left-6 z-[120] space-y-3 max-w-sm w-full">
        {toasts.map(t => (
          <div
            key={t.id}
            className={`flex items-center justify-between gap-3 px-4 py-3 rounded-none border-2 text-xs sm:text-sm font-mono tracking-wider font-bold shadow-lg ${getToastColors(t.type)}`}
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-red-500 shrink-0" />
              <span>{t.message}</span>
            </div>
            <button onClick={() => removeToast(t.id)} className="text-slate-400 hover:text-white shrink-0 p-0.5">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* NAVIGATION BAR */}
      <nav className="bg-[#0f172a] border-b-2 border-slate-800 sticky top-[33px] z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <a href="#" className="flex items-center gap-3.5 group">
            <div className="w-10 h-10 bg-red-650 flex items-center justify-center font-black text-white text-xl border border-white">!</div>
            <div>
              <span className="font-display text-2xl font-black tracking-tighter text-white uppercase">
                ERROR<span className="text-red-500">CONSOLE</span><span className="text-slate-350 text-xs font-bold ml-1 font-mono">NP</span>
              </span>
              <p className="text-[9px] text-slate-400 font-mono tracking-widest font-black uppercase block leading-none">Instant Voucher Engine v2.4</p>
            </div>
          </a>

          {/* Nav Categories */}
          <div className="hidden lg:flex items-center gap-9 text-xs font-mono font-black uppercase tracking-widest text-slate-400">
            <a href="#games-catalog" className="hover:text-red-500 transition-colors relative group">
              CATALOG DIRECT
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-red-500 transition-all group-hover:w-full"></span>
            </a>
            <a href="#advantages" className="hover:text-red-500 transition-colors relative group">
              WHY SECURE
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-red-500 transition-all group-hover:w-full"></span>
            </a>
            <a href="#faq" className="hover:text-red-500 transition-colors relative group">
              NEPAL FAQ
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-red-500 transition-all group-hover:w-full"></span>
            </a>
          </div>

          <div className="flex items-center gap-3">
            {/* Quick search input */}
            <div className="relative hidden md:block">
              <input
                type="text"
                placeholder="Search games..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-60 bg-slate-905 border-2 border-slate-800 rounded-none text-xs py-2 pl-9 pr-4 text-white placeholder-slate-500 focus:border-red-500 focus:w-72 transition-all font-mono tracking-wider"
              />
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>

            {/* Mobile search toggle */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="md:hidden p-2.5 rounded-none border-2 border-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>

            <button
              onClick={() => {
                const target = document.getElementById('order-history-section');
                if (target) {
                  target.scrollIntoView({ behavior: 'smooth' });
                } else {
                  showToast("You have not initiated top-ups in this session.", "info");
                }
              }}
              className="relative p-2.5 rounded-none bg-slate-900 border-2 border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-white transition-all"
            >
              <ShoppingCart className="w-4.5 h-4.5" />
              {orders.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-650 rounded-none text-[9px] font-bold flex items-center justify-center text-white border border-white font-mono animate-pulse">
                  {orders.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* MOBILE SEARCH MODAL OVERLAY */}
      {isSearchOpen && (
        <div className="fixed inset-0 z-[110] bg-[#090d1a]/98 backdrop-blur-3xl flex items-start justify-center pt-20 px-4">
          <div className="w-full max-w-xl">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-red-500 w-5 h-5" />
              <input
                type="text"
                placeholder="Type and filter system..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border-2 border-slate-800 rounded-none pl-12 pr-12 py-4 text-white text-base placeholder-slate-500 focus:border-red-500 transition-all font-mono tracking-widest"
              />
              <button
                onClick={() => { setIsSearchOpen(false); setSearchQuery(''); }}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="mt-6 text-xs font-mono tracking-widest text-slate-500 font-extrabold mb-2">QUICK SYSTEM SEARCH FILTERS:</div>
            <div className="flex flex-wrap gap-2 mb-8">
              {['PUBG', 'Free Fire', 'Valorant', 'Roblox', 'Steam'].map(q => (
                <button
                  key={q}
                  onClick={() => setSearchQuery(q)}
                  className="px-3.5 py-2 rounded-none bg-slate-900 border border-slate-800 text-xs text-slate-300 font-mono hover:text-white hover:bg-slate-800 transition-all cursor-pointer"
                >
                  #{q}
                </button>
              ))}
            </div>

            {/* Live Search List */}
            <div className="mt-4 space-y-2 max-h-[50vh] overflow-y-auto">
              {filteredProducts.slice(0, 5).map(p => {
                const FallbackIcon = iconMap[p.iconName] || Gamepad2;
                return (
                  <button
                    key={p.id}
                    onClick={() => { setIsSearchOpen(false); handleProductCardClick(p); }}
                    className="w-full flex items-center gap-4 p-4 rounded-none bg-slate-950 border-2 border-slate-800 hover:border-red-500 transition-all text-left group cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-none overflow-hidden shrink-0 relative flex items-center justify-center bg-slate-900">
                      {p.image ? (
                        <img src={p.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform" alt={p.name} />
                      ) : (
                        <div className={`w-full h-full bg-gradient-to-br ${p.fallbackColor} flex items-center justify-center`}>
                          <FallbackIcon className="w-5 h-5 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-black tracking-tight text-white uppercase font-display group-hover:text-red-500 transition-colors">{p.name}</h4>
                      <p className="text-slate-400 text-[10px] font-mono tracking-wider">From NPR {p.tiers[0].price} · Instant Direct</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-550" />
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* ===== HERO COMPREHENSIVE CYBER BANNER ================== */}
      {/* ========================================================= */}
      <header className="relative min-h-[80vh] flex items-center overflow-hidden border-b-2 border-slate-800 bg-[#0b0f19]">
        {/* Colorful Blurred Orbs */}
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-red-650/5 rounded-full blur-[140px] pointer-events-none"></div>
        <div className="absolute bottom-[-100px] left-0 w-[500px] h-[500px] bg-slate-800/20 rounded-full blur-[120px] pointer-events-none"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full z-10">
          <div className="grid lg:grid-cols-12 gap-16 items-center">
            
            {/* HERO LEFT TEXT */}
            <div className="lg:col-span-7">
              <div className="flex items-center gap-3 mb-6.5">
                <div className="h-0.5 bg-red-500 w-12"></div>
                <span className="font-mono text-xs font-black tracking-[0.2em] uppercase text-red-500">NEPAL DIRECT GAME ENGINE HUB</span>
                <span className="bg-red-500/10 border border-red-500/30 text-red-500 text-[9px] font-mono font-black px-2 py-0.5 rounded-none uppercase tracking-wider animate-pulse">VERIFIED SUITE v2.4</span>
              </div>

              <h1 className="font-display font-black leading-[0.85] tracking-tight mb-6">
                <span className="block text-4xl sm:text-6xl xl:text-[85px] text-white">INSTANT RAW</span>
                <span className="block text-4.5xl sm:text-6.5xl xl:text-[90px] text-red-550 italic uppercase tracking-tighter">VOUCHERS DIRECT</span>
                <span className="block text-4xl sm:text-6xl xl:text-[85px] text-white">IN 15 SECONDS</span>
              </h1>

              <div className="h-1 bg-red-500 w-32 mb-8"></div>

              <p className="text-slate-300 text-base sm:text-lg max-w-xl mb-10 leading-relaxed font-sans">
                Never wait for manual WhatsApp replies or share passwords again. Top up your favorite game tokens using Nepalese secure merchants <span className="text-white font-black underline decoration-red-550">eSewa, Khalti, IME Pay, and IPS bank systems</span> natively.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-10">
                <a
                  href="#games-catalog"
                  className="bg-red-600 hover:bg-red-750 text-white text-center inline-flex items-center justify-center gap-2.5 font-mono font-black px-8 py-5 rounded-none text-base tracking-widest transition-all border-2 border-white uppercase"
                >
                  <Gamepad className="w-5 h-5 animate-pulse" />
                  TOP UP CATALOG
                </a>
                <a
                  href="#advantages"
                  className="inline-flex items-center justify-center gap-2.5 bg-slate-900 border-2 border-slate-800 text-slate-105 font-mono font-black px-8 py-5 rounded-none text-base tracking-widest hover:bg-slate-800 transition-all uppercase"
                >
                  <Shield className="w-5 h-5 text-red-500" />
                  SECURITY SPECS
                </a>
              </div>

              {/* Supported payment labels */}
              <div className="flex flex-wrap items-center gap-2.5">
                <span className="font-mono text-[10px] text-slate-500 tracking-widest font-black mr-1.5">ACCEPTED GATEWAYS:</span>
                {['eSewa Instant', 'Khalti Direct', 'IME Pay Merchant', 'ConnectIPS Bank'].map((pay, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded-none px-3.5 py-1.5 text-xs font-mono font-bold text-slate-400"
                  >
                    <span className="w-2 h-2 bg-emerald-500"></span>
                    {pay}
                  </span>
                ))}
              </div>
            </div>

            {/* HERO RIGHT SECURE INTERACTIVE FLUID CARD */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative group/hero flex justify-center items-center">
                {/* Neon Background Blobs */}
                <div className="absolute inset-0 bg-red-600/5 rounded-none blur-xl group-hover/hero:scale-115 transition-transform duration-500"></div>
                
                {/* Main Card */}
                <div className="w-80 rounded-none bg-slate-900 border-2 border-slate-800 overflow-hidden relative z-10 shadow-2xl">
                  <div className="h-44 relative overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600" 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover/hero:scale-105" 
                      alt="Cyber Gaming"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent"></div>
                    <div className="absolute bottom-4 left-4">
                      <span className="bg-red-650 rounded-none px-2 py-0.5 text-[9px] font-mono font-black text-white tracking-widest uppercase border border-white">
                        🔥 HOT PICK
                      </span>
                      <h3 className="font-display font-black text-2xl tracking-tight text-white mt-1.5 uppercase">PUBG MOBILE VOUCHERS</h3>
                    </div>
                  </div>

                  <div className="p-5 space-y-3 bg-slate-950">
                    <div className="flex justify-between items-center bg-slate-900 border border-slate-800 rounded-none px-4 py-3">
                      <span className="text-xs text-slate-400 font-mono tracking-wider">60 UC Voucher</span>
                      <span className="text-sm font-black text-slate-105 font-mono">NPR 120</span>
                    </div>
                    <div className="flex justify-between items-center bg-red-950/30 border-2 border-red-500/50 rounded-none px-4 py-3">
                      <span className="text-xs text-white font-mono font-black tracking-wider flex items-center gap-1.5">
                        <Sparkle className="w-3.5 h-3.5 text-red-500" /> 325 UC Bundle
                      </span>
                      <span className="text-sm font-black text-red-400 font-mono">NPR 599</span>
                    </div>
                    <div className="flex justify-between items-center bg-slate-900 border border-slate-800 rounded-none px-4 py-3">
                      <span className="text-xs text-slate-400 font-mono tracking-wider">660 UC Voucher</span>
                      <span className="text-sm font-black text-slate-105 font-mono">NPR 1,150</span>
                    </div>
                  </div>

                  <div className="px-5 pb-5 bg-slate-950">
                    <div className="flex items-center justify-center gap-2 bg-slate-900 border border-slate-800 rounded-none py-3 text-[10px] font-mono font-black tracking-widest text-[#ef4444] uppercase">
                      <Zap className="w-3.5 h-3.5 animate-bounce text-red-500" /> INSTANT AUTOMATED PACKETS
                    </div>
                  </div>
                </div>

                {/* Floating Micro-Information Badges */}
                <div 
                  className="absolute -bottom-6 -left-10 w-24 h-24 rounded-none bg-slate-950 border-2 border-slate-800 flex flex-col items-center justify-center text-center p-2.5 rotate-3 z-20"
                >
                  <Lock className="w-5 h-5 text-red-500 mb-1" />
                  <p className="text-[8px] text-white font-mono font-black leading-tight uppercase tracking-wider">CHAR ID<br/>SAFE GATE</p>
                </div>

                <div 
                  className="absolute top-[-20px] -right-8 w-24 h-24 rounded-none bg-slate-950 border-2 border-slate-800 flex flex-col items-center justify-center text-center p-2.5 -rotate-6 z-20"
                >
                  <Zap className="w-6 h-6 text-red-500 mb-1" />
                  <p className="text-[8px] text-white font-mono font-black leading-tight uppercase tracking-wider">INSTANT<br/>VOUCHERS</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </header>

      {/* QUICK SYSTEM STATS BLOCK */}
      <section className="bg-slate-950 border-b-2 border-slate-800 backdrop-blur-sm relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 text-center">
            <div>
              <div className="font-display font-black text-3xl sm:text-4xl text-red-500 leading-none">52,400+</div>
              <div className="text-slate-400 text-[10px] sm:text-xs font-mono tracking-widest font-black mt-1.5 uppercase">DISPATCHED SECURES</div>
            </div>
            <div>
              <div className="font-display font-black text-3xl sm:text-4xl text-slate-105 leading-none">20 ACTIVE</div>
              <div className="text-slate-400 text-[10px] sm:text-xs font-mono tracking-widest font-black mt-1.5 uppercase">VERIFIED PIXEL VOUCHERS</div>
            </div>
            <div>
              <div className="font-display font-black text-3xl sm:text-4xl text-emerald-450 leading-none">15 SEC SECS</div>
              <div className="text-slate-400 text-[10px] sm:text-xs font-mono tracking-widest font-black mt-1.5 uppercase">AVERAGE LATENCY TARGET</div>
            </div>
            <div>
              <div className="font-display font-black text-3xl sm:text-4xl text-red-500 leading-none">99.8%</div>
              <div className="text-slate-400 text-[10px] sm:text-xs font-mono tracking-widest font-black mt-1.5 uppercase">HEALTH INDEX DETECTION</div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================= */}
      {/* ===== MASTER CATALOGUE SECTION ========================= */}
      {/* ========================================================= */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-20" id="games-catalog">
        
        {/* Category Header & Filter */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-2.5 mb-2.5">
              <div className="h-0.5 bg-red-500 w-8"></div>
              <span className="font-mono text-xs font-black tracking-widest uppercase text-red-500">Nepal Certified Direct-API Webhook gateway</span>
            </div>
            <h2 className="font-display font-black text-4xl sm:text-[50px] tracking-tighter leading-none">GAMES & GIFT VOUCHERS</h2>
            <p className="text-gray-500 text-sm mt-2.5 max-w-md">Filter by direct top-up system or email code-delivered vouchers.</p>
          </div>

          {/* Filtering tabs */}
          <div className="flex items-center gap-1.5 p-1.5 bg-slate-950 rounded-none border-2 border-slate-800">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-4.5 py-2 rounded-none text-xs font-mono font-black tracking-widest transition-all cursor-pointer ${
                selectedCategory === 'all' 
                  ? 'bg-red-600 text-white' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              ALL ITEMS
            </button>
            <button
              onClick={() => setSelectedCategory('game')}
              className={`px-4.5 py-2 rounded-none text-xs font-mono font-black tracking-widest transition-all cursor-pointer ${
                selectedCategory === 'game' 
                  ? 'bg-red-600 text-white' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              GAMES DIRECT
            </button>
            <button
              onClick={() => setSelectedCategory('giftcard')}
              className={`px-4.5 py-2 rounded-none text-xs font-mono font-black tracking-widest transition-all cursor-pointer ${
                selectedCategory === 'giftcard' 
                  ? 'bg-red-600 text-white' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              GIFT CODES
            </button>
          </div>
        </div>

        {/* Catalog Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-24 bg-slate-900 rounded-none border-2 border-slate-800">
            <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4 animate-bounce" />
            <h3 className="text-xl font-black tracking-tight text-white uppercase font-display">No matching vouchers found</h3>
            <p className="text-slate-450 mt-1.5 text-xs max-w-sm mx-auto font-mono">Refine your keyword search or change categories.</p>
            <button 
              onClick={() => { setSearchQuery(''); setSelectedCategory('all'); }} 
              className="mt-6 text-xs font-mono font-black bg-slate-950 border border-slate-800 hover:bg-slate-800 text-white px-5 py-2.5 rounded-none uppercase cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5 sm:gap-6 mb-20" id="gamesGrid">
            {filteredProducts.map((p) => {
              const DynamicIcon = iconMap[p.iconName] || Gamepad2;
              return (
                <div 
                  key={p.id}
                  onClick={() => handleProductCardClick(p)}
                  className="group bg-slate-900 border-2 border-slate-800 rounded-none overflow-hidden cursor-pointer transition-all hover:border-red-500 hover:bg-slate-950"
                >
                  <div className="aspect-square relative overflow-hidden bg-slate-950">
                    {p.image ? (
                      <img 
                        src={p.image} 
                        alt={p.name} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        loading="lazy"
                      />
                    ) : (
                      <div className={`w-full h-full bg-gradient-to-br ${p.fallbackColor} flex items-center justify-center`}>
                        <DynamicIcon className="w-10 h-10 text-white" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/35 to-transparent"></div>
                    
                    {/* Floating Hot and Popular Badges */}
                    {p.tag && (
                      <span className={`absolute top-3.5 left-3.5 z-10 text-[9px] font-mono font-black tracking-widest px-2 py-0.5 rounded-none border-2 border-white ${
                        p.tag === 'HOT' 
                          ? 'bg-red-650 text-white' 
                          : p.tag === 'NEW' 
                            ? 'bg-slate-900 text-white'
                            : 'bg-black text-white'
                      }`}>
                        {p.tag}
                      </span>
                    )}

                    <div className="absolute bottom-3 left-3.5 right-3.5 text-left">
                      <h3 className="font-display font-black text-lg tracking-tight text-white group-hover:text-red-500 transition-colors uppercase leading-tight truncate">
                        {p.name}
                      </h3>
                    </div>
                  </div>

                  <div className="p-4 flex items-center justify-between bg-slate-950 border-t border-slate-800">
                    <div className="text-left">
                      <span className="text-slate-550 text-[9px] font-mono tracking-widest font-black block leading-none">PACKS FROM</span>
                      <span className="text-emerald-400 font-mono font-black text-lg mt-1 block">NPR {p.tiers[0].price.toLocaleString()}</span>
                    </div>
                    <div className="w-9 h-9 rounded-none bg-slate-900 border border-slate-800 flex items-center justify-center group-hover:bg-red-650 group-hover:text-white text-slate-400 transition-all">
                      <ChevronRight className="w-5 h-5 text-white" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* FEED AND ONGOING TRANSACTION SPLIT SECTION */}
        <div className="grid lg:grid-cols-12 gap-8 items-start mb-24">
          <div className="lg:col-span-6 space-y-8">
            <LiveTransactionFeed />
          </div>
          <div className="lg:col-span-6 space-y-8">
            <MyOrdersTracker orders={orders} onClear={handleClearOrders} />
          </div>
        </div>

        {/* ========================================================= */}
        {/* ===== ADVANTAGES BENEFITS GRID ========================= */}
        {/* ========================================================= */}
        <section className="bg-slate-900 border-2 border-slate-800 rounded-none p-8 sm:p-12 mb-24 relative overflow-hidden" id="advantages">
          <div className="absolute top-0 right-0 w-48 h-48 bg-red-500/5 rounded-full blur-3xl pointer-events-none"></div>

          <div className="text-center mb-12 max-w-xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/35 rounded-none px-3.5 py-1 mb-3.5">
              <span className="w-1.5 h-1.5 rounded-none bg-red-500 animate-pulse"></span>
              <span className="text-[10px] text-red-500 font-mono font-black tracking-widest uppercase">Safe Gateway Nepal</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white uppercase font-display">ENGINEERED FOR SECURE DISPATCH</h2>
            <p className="text-slate-400 text-xs sm:text-sm mt-2 font-mono tracking-wide">Direct system endpoints avoid manual delays or password handovers completely.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6.5">
            <div className="bg-slate-950 p-6 rounded-none border-2 border-slate-800 hover:border-red-500 transition-all">
              <div className="w-12 h-12 rounded-none bg-slate-950 border border-slate-800 flex items-center justify-center mb-5 hover:bg-red-650 transition-all">
                <Lock className="w-5 h-5 text-red-500" />
              </div>
              <h3 className="text-base font-black tracking-tight text-white uppercase font-display mb-2">Character Direct UID</h3>
              <p className="text-slate-450 text-xs leading-relaxed font-sans">
                No credentials requested. Game accounts are credited securely utilizing official character identifiers.
              </p>
            </div>

            <div className="bg-slate-950 p-6 rounded-none border-2 border-slate-800 hover:border-red-500 transition-all">
              <div className="w-12 h-12 rounded-none bg-slate-950 border border-slate-800 flex items-center justify-center mb-5 hover:bg-red-650 transition-all">
                <CheckCircle className="w-5 h-5 text-red-500" />
              </div>
              <h3 className="text-base font-black tracking-tight text-white uppercase font-display mb-2">API Automation</h3>
              <p className="text-slate-450 text-xs leading-relaxed font-sans">
                Automatic API callbacks listen to Nepal wallet merchant transactions. Instant dispatch within seconds.
              </p>
            </div>

            <div className="bg-slate-950 p-6 rounded-none border-2 border-slate-800 hover:border-red-500 transition-all">
              <div className="w-12 h-12 rounded-none bg-slate-950 border border-slate-800 flex items-center justify-center mb-5 hover:bg-red-650 transition-all">
                <Cpu className="w-5 h-5 text-red-300" />
              </div>
              <h3 className="text-base font-black tracking-tight text-white uppercase font-display mb-2">Local Integration</h3>
              <p className="text-slate-450 text-xs leading-relaxed font-sans">
                Optimized specifically for eSewa, Khalti, and IME Pay. Zero conversion fees. High processing success rates.
              </p>
            </div>
          </div>
        </section>

        {/* ========================================================= */}
        {/* ===== FREQUENTLY ASKED QUESTIONS ======================= */}
        {/* ========================================================= */}
        <section className="max-w-3xl mx-auto py-10" id="faq">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-[42px] font-black tracking-tight text-white uppercase font-display">Nepal Top-Up FAQ</h2>
            <p className="text-slate-500 text-xs sm:text-sm mt-3 font-mono tracking-widest uppercase">Answers for game credit dispatches</p>
          </div>

          <div className="space-y-3.5">
            {FAQS.map((faq, idx) => {
              const isFaqActive = activeFaqIndex === idx;
              return (
                <div 
                  key={idx}
                  className="bg-slate-900 border-2 border-slate-800 rounded-none overflow-hidden"
                >
                  <button 
                    onClick={() => setActiveFaqIndex(isFaqActive ? null : idx)}
                    className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-950 transition-colors cursor-pointer"
                  >
                    <span className="text-sm sm:text-base font-black text-white hover:text-red-500 uppercase tracking-tight transition-colors">
                      {faq.q}
                    </span>
                    <ChevronDown className={`w-4.5 h-4.5 text-slate-500 shrink-0 transition-transform duration-300 ${isFaqActive ? 'rotate-180 text-red-500' : ''}`} />
                  </button>
                  
                  {isFaqActive && (
                    <div className="px-5 pb-5 animate-fade-in border-t border-white/[0.02] pt-4.5">
                      <p className="text-gray-400 text-xs sm:text-sm leading-relaxed font-sans">{faq.a}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

      </main>

      {/* ========================================================= */}
      {/* ===== FIRST LEVEL DETAIL CHOOSE MODAL ================= */}
      {/* ========================================================= */}
      {selectedProduct && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-[#090d1a]/95 backdrop-blur-md" 
            onClick={() => setSelectedProduct(null)}
          ></div>
          <div 
            className="relative bg-slate-950 border-2 border-slate-800 rounded-none w-full max-w-lg max-h-[92vh] overflow-y-auto shadow-2xl p-6 sm:p-7 z-10"
          >
            {/* Close */}
            <button 
              onClick={() => setSelectedProduct(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white bg-slate-900 hover:bg-red-600 rounded-none p-2 border border-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-4.5 h-4.5" />
            </button>

            {/* Product Hero Header */}
            <div className="flex items-center gap-4.5 border-b-2 border-slate-800 pb-5 mb-5.5">
              <div className="w-14 h-14 rounded-none bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0">
                {React.createElement(iconMap[selectedProduct.iconName] || Gamepad2, { className: 'w-7 h-7 text-red-500' })}
              </div>
              <div>
                <span className="bg-red-500/15 text-red-400 border border-red-500/30 rounded-none px-2 py-0.5 text-[9px] font-mono font-black tracking-widest uppercase">
                  DIRECT API INJECTION SECURE
                </span>
                <h3 className="font-display font-black text-2xl text-white tracking-tight mt-1 leading-none uppercase">{selectedProduct.name}</h3>
              </div>
            </div>

            {/* Security Warning Notice */}
            <div className="bg-red-950/20 border-l-4 border-red-500 rounded-none p-4 mb-5.5 flex items-start gap-3">
              <Shield className="w-4.5 h-4.5 text-red-500 shrink-0 mt-0.5" />
              <p className="text-[11px] text-slate-300 font-mono leading-relaxed">
                <span className="font-black uppercase block tracking-wider mb-0.5 text-white text-xs">DIRECT INTEGRITY SECURE:</span>
                We will NEVER request password details or SMS OTP. Top-ups execute purely on target character identifiers.
              </p>
            </div>

            {/* Tiers choosing flow */}
            <div className="mb-5.5">
              <label className="font-mono font-black text-[10px] tracking-widest uppercase text-slate-400 mb-2.5 block">SELECT VOUCHER TIERS</label>
              <div className="grid grid-cols-2 gap-3 max-h-56 overflow-y-auto pr-1">
                {selectedProduct.tiers.map((tier, idx) => {
                  const isSelected = selectedTier === tier;
                  return (
                    <button
                      key={idx}
                      onClick={() => setSelectedTier(tier)}
                      className={`text-left rounded-none p-3.5 border-2 transition-all cursor-pointer ${
                        isSelected 
                          ? 'bg-red-500/10 border-red-500 text-white shadow-lg' 
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:bg-slate-850'
                      }`}
                    >
                      <div className="text-xs font-mono font-bold tracking-wide text-white">{tier.label}</div>
                      <div className="text-xl font-display font-black text-emerald-400 mt-1 leading-none">NPR {tier.price.toLocaleString()}</div>
                      {tier.originalPrice && (
                        <div className="text-[10px] text-slate-500 line-through mt-1 font-mono">NPR {tier.originalPrice.toLocaleString()}</div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Requires identifier input */}
            <div className="mb-6.5">
              <label className="font-mono font-black text-[10px] tracking-widest uppercase text-slate-400 mb-2 block">
                {selectedProduct.requires}
              </label>
              <input
                type="text"
                placeholder={selectedProduct.placeholder}
                value={targetId}
                onChange={(e) => setTargetId(e.target.value)}
                className="w-full bg-slate-900 border-2 border-slate-800 rounded-none px-4 py-3 text-white text-sm font-mono placeholder-slate-600 focus:border-red-500 focus:outline-none transition-all uppercase"
              />
              <p className="text-[10px] text-slate-500 italic mt-2.5 font-mono leading-normal">
                ⚠️ Double check: Misspelled identifiers will inject tokens into other user logs. Gateway processing is final and irreversible.
              </p>
            </div>

            {/* Next trigger */}
            {selectedTier ? (
              <button
                onClick={handleProceedToCheckout}
                className="w-full bg-red-650 hover:bg-red-750 text-white font-mono font-black py-4.5 rounded-none border border-white transition-all text-sm tracking-[0.2em] uppercase cursor-pointer"
              >
                PROCEED TO DISPATCH — NPR {selectedTier.price.toLocaleString()}
              </button>
            ) : (
              <button
                disabled
                className="w-full bg-slate-900 border-2 border-slate-800 text-slate-600 font-mono font-bold py-4 rounded-none text-xs tracking-[0.2em] uppercase cursor-not-allowed"
              >
                SELECT VALUE TO CONTINUE
              </button>
            )}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* ===== SECOND LEVEL REDIRECT GATEWAY MODAL ============== */}
      {/* ========================================================= */}
      {checkoutProduct && selectedTier && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-[#090d1a]/97 backdrop-blur-md" 
            onClick={() => { if (!isProcessingCheckout) setCheckoutProduct(null); }}
          ></div>
          <div 
            className="relative bg-slate-950 border-2 border-slate-800 rounded-none w-full max-w-lg max-h-[92vh] overflow-y-auto shadow-2xl p-6 sm:p-7 z-10"
          >
            {/* Close button */}
            {!isProcessingCheckout && (
              <button 
                onClick={() => setCheckoutProduct(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white bg-slate-900 hover:bg-red-600 rounded-none p-2 border border-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            )}

            {/* Standard layout show */}
            {!successfulOrder && (
              <>
                <div className="text-center mb-6 border-b-2 border-slate-800 pb-4">
                  <h3 className="text-2xl font-black tracking-tight text-white uppercase font-display leading-none">Gateway Authorization</h3>
                  <p className="text-red-500 text-[10px] font-mono tracking-widest uppercase mt-2 font-bold font-mono">Zero Login Session · Direct Broadcast Webhook</p>
                </div>

                {/* Top-up details card overview */}
                <div className="bg-slate-900 border-2 border-slate-800 rounded-none p-4 mb-5.5">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-none bg-slate-950 border border-slate-800 flex items-center justify-center">
                        <Gamepad className="w-5 h-5 text-red-500" />
                      </div>
                      <div>
                        <h4 className="text-sm text-white font-black uppercase font-display">{checkoutProduct.name}</h4>
                        <p className="text-slate-400 text-xs font-mono">{selectedTier.label}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-[10.5px] text-slate-500 font-mono block leading-none font-black uppercase">PAYMENT NPR</span>
                      <span className="font-mono font-black text-xl text-emerald-400 mt-1 block">NPR {selectedTier.price.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="border-t border-slate-800 pt-2.5 mt-3 flex justify-between text-xs font-mono">
                    <span className="text-slate-500">Player Destination:</span>
                    <span className="text-white font-black">{targetId}</span>
                  </div>
                </div>

                {/* Cyber warning badge */}
                <div className="bg-slate-900 border border-slate-800 rounded-none p-4 mb-5.5 flex items-start gap-2.5">
                  <Sparkles className="w-4.5 h-4.5 text-red-500 shrink-0 mt-0.5" />
                  <p className="text-[11px] text-slate-300 font-mono leading-relaxed">
                    <span className="font-black text-white uppercase block mb-0.5">Automated Webhook Ledger:</span>
                    Our backend establishes direct connections to Nepalese merchants. Tokens deliver on connection clearance automatically.
                  </p>
                </div>

                {/* Payment selectors */}
                <div className="mb-5.5">
                  <label className="font-mono font-black text-[10px] tracking-widest uppercase text-slate-400 mb-2.5 block">SELECT PAYMENT MERCHANT</label>
                  <div className="space-y-2">
                    {PAYMENT_METHODS.map(pm => {
                      const isSelected = selectedPayment?.id === pm.id;
                      return (
                        <button
                          key={pm.id}
                          onClick={() => { if (!isProcessingCheckout) setSelectedPayment(pm); }}
                          className={`w-full flex items-center justify-between p-3.5 rounded-none border-2 text-left transition-all relative cursor-pointer ${
                            isSelected 
                              ? 'bg-red-550/10 border-red-500' 
                              : 'bg-slate-900 border-slate-800 hover:bg-slate-850'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <span className={`w-9 h-9 rounded-none bg-gradient-to-br ${pm.bgGradient} flex items-center justify-center shrink-0 border border-slate-700`}>
                              {React.createElement(iconMap[pm.iconName] || Wallet, { className: 'w-4.5 h-4.5 text-white' })}
                            </span>
                            <div>
                              <span className="font-display font-black text-sm text-white block uppercase">{pm.name}</span>
                              <span className="text-[10px] text-slate-500 font-mono tracking-wider">Zero merchant processing fee</span>
                            </div>
                          </div>
                          
                          {/* Inner selected square indicator */}
                          <div className={`w-4 h-4 rounded-none border-2 flex items-center justify-center ${isSelected ? 'border-red-500' : 'border-slate-800'}`}>
                            {isSelected && <div className="w-2 h-2 rounded-none bg-red-500"></div>}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Specific Gateway instructional panel details */}
                {selectedPayment && (
                  <div className="bg-slate-900 border-2 border-slate-800 rounded-none p-4.5 mb-5.5">
                    <h4 className="text-xs font-mono font-black text-red-500 tracking-wider mb-2 uppercase flex items-center gap-1.5 leading-none">
                      <Info className="w-4 h-4 text-red-500" /> Transfer Instructions
                    </h4>
                    <p className="text-[11px] text-slate-300 font-mono leading-relaxed mb-3.5">{selectedPayment.instructions}</p>

                    {selectedPayment.accountDetails && (
                      <div className="bg-slate-950 border border-slate-800 rounded-none p-3.5 space-y-2 text-xs font-mono">
                        {selectedPayment.accountDetails.bankName && (
                          <div className="flex justify-between border-b border-slate-800 pb-1.5 mb-1.5">
                            <span className="text-slate-500">Bank Name:</span>
                            <span className="text-white font-bold uppercase">{selectedPayment.accountDetails.bankName}</span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-slate-500">Receiver Name:</span>
                          <span className="text-red-400 font-bold text-right uppercase">{selectedPayment.accountDetails.accountName}</span>
                        </div>
                        <div className="flex justify-between border-t border-slate-800 pt-2">
                          <span className="text-slate-500">Receiver Acc / Phone:</span>
                          <span className="text-white font-bold text-right tracking-widest">{selectedPayment.accountDetails.accountNumber}</span>
                        </div>
                      </div>
                    )}

                    {/* Screenshot File deposit uploader specifically for direct interbank IPS transfers */}
                    {selectedPayment.id === 'bank' && (
                      <div className="mt-4 border-t-2 border-slate-800 pt-4">
                        <label className="font-mono font-black text-[10px] tracking-widest uppercase text-slate-400 mb-2 block">Upload bank screenshot invoice receipt</label>
                        <div 
                          onClick={triggerMockUpload}
                          className="border-2 border-dashed border-slate-800 hover:border-red-500 rounded-none p-4.5 text-center cursor-pointer transition-colors bg-slate-950 hover:bg-slate-900"
                        >
                          <ImageIcon className="w-6 h-6 text-red-500 mx-auto mb-1.5 animate-pulse" />
                          <p className="text-[11px] text-white font-mono font-black tracking-wider uppercase leading-none">Attach Transaction Image</p>
                          <p className="text-[9px] text-slate-600 mt-1 font-mono leading-none">PNG / JPEG max limit 5MB</p>
                        </div>
                        <input
                          type="file"
                          id="receipt-screenshot-uploader"
                          className="hidden"
                          accept="image/*"
                          onChange={handleFileChange}
                        />
                        {receiptFile && (
                          <div className="mt-2 text-xs text-red-500 font-mono flex items-center gap-1.5 leading-none">
                            <Check className="w-3.5 h-3.5 text-emerald-400" /> Linked: <span className="underline italic truncate max-w-xs">{receiptFile.name}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Final Trigger order action button */}
                {isProcessingCheckout ? (
                  <div className="space-y-4 bg-slate-900 border-2 border-slate-800 rounded-none p-5">
                    <div className="flex items-center justify-between text-xs font-mono font-black text-red-500">
                      <span className="flex items-center gap-1.5"><Loader2 className="w-3.5 h-3.5 animate-spin text-red-500" /> Handshaking voucher packet...</span>
                      <span className="text-white font-mono">{checkoutStage * 20}%</span>
                    </div>
                    <div className="h-2 bg-slate-950 rounded-none border border-slate-800 overflow-hidden">
                      <div 
                        className="h-full bg-red-650 transition-all duration-300"
                        style={{ width: `${checkoutStage * 20}%` }}
                      ></div>
                    </div>
                    <p className="text-[10px] text-slate-500 italic font-mono text-center leading-none">
                      {checkoutStage === 0 && "Locating character UID handshake..."}
                      {checkoutStage === 1 && "Verifying character ID profile..."}
                      {checkoutStage === 2 && "Authenticating Nepali payment gateway..."}
                      {checkoutStage === 3 && "Connecting official API top-up server..."}
                      {checkoutStage === 4 && "Finalizing coin injection payloads..."}
                      {checkoutStage === 5 && "Completed!"}
                    </p>
                  </div>
                ) : (
                  selectedPayment ? (
                    <button
                      onClick={handleTriggerPayment}
                      className="w-full bg-red-650 hover:bg-red-750 text-white font-mono font-black py-4.5 rounded-none border border-white transition-all text-sm tracking-[0.2em] uppercase cursor-pointer"
                    >
                      CONFIRM PAYMENT — NPR {selectedTier.price.toLocaleString()}
                    </button>
                  ) : (
                    <button
                      disabled
                      className="w-full bg-slate-900 border-2 border-slate-800 text-slate-600 font-mono font-bold py-4.5 rounded-none text-xs tracking-[0.2em] uppercase cursor-not-allowed"
                    >
                      SELECT A PAYMENT MERCHANT ABOVE
                    </button>
                  )
                )}
              </>
            )}

            {/* Simulated Receipt complete invoices showcase view */}
            {successfulOrder && (
              <div className="text-center py-3">
                <div className="w-16 h-16 rounded-none bg-slate-900 border-2 border-green-500 flex items-center justify-center mx-auto mb-5.5">
                  <CheckCircle className="w-8 h-8 text-green-500" />
                </div>
                
                <h3 className="text-2xl font-black text-white tracking-tight uppercase leading-none font-display">ORDER REGISTERED</h3>
                <p className="text-red-500 text-[10px] mt-2.5 font-mono tracking-widest uppercase font-bold">Voucher Injection Node Initialized</p>

                <div className="bg-slate-900 border-2 border-slate-800 rounded-none p-5 space-y-3 mt-6 mb-6">
                  <div className="flex justify-between items-center text-xs font-mono pb-2 border-b border-slate-800 leading-none">
                    <span className="text-slate-500">ORDER UUID Code:</span>
                    <span className="text-red-400 font-bold">{successfulOrder.id}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-mono pb-2 border-b border-slate-800 leading-none">
                    <span className="text-slate-500">Character Product:</span>
                    <span className="text-white font-bold">{successfulOrder.product.name}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-mono pb-2 border-b border-slate-800 leading-none">
                    <span className="text-slate-500">Tier Selected:</span>
                    <span className="text-white font-bold">{successfulOrder.selectedTier.label}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-mono pb-2 border-b border-slate-800 leading-none">
                    <span className="text-slate-500">Destination target:</span>
                    <span className="text-white font-black tracking-widest">{successfulOrder.targetId}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-mono pb-2 border-b border-slate-800 leading-none">
                    <span className="text-slate-500">Nepali gateway:</span>
                    <span className="text-white font-bold uppercase">{successfulOrder.paymentMethod.name}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-mono leading-none">
                    <span className="text-slate-500 font-semibold uppercase">TOTAL PRICE:</span>
                    <span className="text-emerald-400 font-bold text-sm">NPR {successfulOrder.selectedTier.price.toLocaleString()}</span>
                  </div>
                </div>

                <div className="bg-slate-900 border-l-4 border-red-500 rounded-none p-4 mb-6 flex items-start gap-3">
                  <Info className="w-4.5 h-4.5 text-red-500 shrink-0 mt-0.5" />
                  <p className="text-[10px] text-slate-350 font-mono leading-relaxed text-left">
                    Your coin ledger has entered our real-time packet stream queuing. Average character direct injection takes approximately 15-30 seconds! Follow live pipeline state below under session history.
                  </p>
                </div>

                <button 
                  onClick={() => setCheckoutProduct(null)} 
                  className="w-full bg-slate-900 border border-slate-800 hover:bg-slate-850 hover:text-red-500 text-white font-mono font-black py-4 rounded-none transition-all tracking-[0.20em] text-xs uppercase cursor-pointer"
                >
                  DISMISS INVOICE RECEIPT
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* ===== WEBSITE FOOTER INFORMATION ======================= */}
      {/* ========================================================= */}
      <footer className="bg-slate-950 border-t-4 border-slate-800 mt-20 relative z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-9 h-9 rounded-none bg-red-650 flex items-center justify-center">
                  <Gamepad2 className="w-5 h-5 text-white" />
                </div>
                <span className="font-display text-lg font-black text-white tracking-tight">GAME<span className="text-red-500">TOPUP</span><span className="text-white text-xs ml-1 font-mono">NP</span></span>
              </div>
              <p className="text-slate-450 text-xs sm:text-sm leading-relaxed font-sans mb-4">
                Nepal's safest automated gaming top-up node. We direct-transfer official game vouchers instantly across Nepalese payment networks without registration.
              </p>
              <div className="inline-flex items-center gap-2 text-[10px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-none font-bold uppercase">
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-none animate-pulse inline-block"></span>
                ALL CORE API GATEWAYS ONLINE
              </div>
            </div>

            <div>
              <h4 className="font-mono font-black text-xs tracking-widest text-slate-400 mb-5 uppercase">Direct Links</h4>
              <ul className="space-y-2.5 text-xs text-slate-500 font-mono tracking-widest font-bold uppercase">
                <li><a href="#games-catalog" className="hover:text-red-500 transition-colors">Vouchers catalog</a></li>
                <li><a href="#advantages" className="hover:text-red-500 transition-colors">Security direct</a></li>
                <li><a href="#faq" className="hover:text-red-500 transition-colors">Frequently questions</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-mono font-black text-xs tracking-widest text-slate-400 mb-5 uppercase">Payment Methods</h4>
              <ul className="space-y-2.5 text-xs text-slate-500 font-mono font-bold uppercase">
                <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-red-500" /> eSewa Wallet</li>
                <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-red-500" /> Khalti Digital</li>
                <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-red-500" /> IME Pay Mobile</li>
                <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-red-500" /> MyPay Wallet</li>
                <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-red-500" /> ConnectIPS raw</li>
              </ul>
            </div>

            <div>
              <h4 className="font-mono font-black text-xs tracking-widest text-slate-400 mb-5 uppercase">Official Support</h4>
              <div className="space-y-4 text-xs text-slate-500 font-mono">
                <p className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-red-500" /> Helper Chat: Available 24/7 (AI Mode)
                </p>
                <p className="flex items-center gap-2">
                  <X className="w-4 h-4 text-red-500 shrink-0" /> support@gametopupnp.com
                </p>
                <p className="text-[10px] text-slate-650 border-t border-slate-900 pt-3 leading-relaxed">
                  Disclaimer: GameTopUp NP is an independent gaming voucher gateway and is not affiliated with, or endorsed by, any trademarked game publisher.
                </p>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-905 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <span className="text-[10px] text-slate-600 font-mono tracking-wider text-center md:text-left uppercase">
              &copy; 2026 GAMETOPUP NP GATEWAYS LTD. REGISTERED AUTOMATED MERCHANTS. ALL TRADEMARKS REGISTERED TO RESPECTIVE OWNERS.
            </span>
            <div className="flex items-center gap-4 text-slate-500">
              <a href="#" className="hover:text-red-500 transition-colors"><Facebook className="w-4.5 h-4.5" /></a>
              <a href="#" className="hover:text-red-500 transition-colors"><Instagram className="w-4.5 h-4.5" /></a>
              <a href="#" className="hover:text-red-500 transition-colors"><Youtube className="w-4.5 h-4.5" /></a>
            </div>
          </div>
        </div>
      </footer>

      {/* ========================================================= */}
      {/* ===== AI CHATBOT AGENT PANEL DOCKED MODAL ============== */}
      {/* ========================================================= */}
      <SupportAgent />
    </div>
  );
}
