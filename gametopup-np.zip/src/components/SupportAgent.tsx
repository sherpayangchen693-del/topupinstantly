import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Zap, User, Sparkles, AlertCircle } from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function SupportAgent() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "Namaste! 🙏 I am your GameTopUp NP Support Assistant. Need help finding your PUBG UID, redeeming a Roblox gift card, or checking eSewa/Khalti details? Ask me anything!",
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to latest message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isLoading) return;

    const userText = inputMessage;
    setInputMessage('');
    setHasError(false);

    const newUserMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: userText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newUserMessage]);
    setIsLoading(true);

    try {
      // Limit actual conversation history sent to keep context compact
      const conversationHistory = messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      const response = await fetch('/api/support-chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: userText,
          history: conversationHistory
        })
      });

      if (!response.ok) {
        throw new Error('Support system API offline.');
      }

      const data = await response.json();
      
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.text,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err) {
      console.error(err);
      setHasError(true);
      // Add local helpful guidance fallback in case server response fails
      const fallbackMessage: ChatMessage = {
        id: (Date.now() + 2).toString(),
        role: 'assistant',
        content: "I'm currently running in local assistant mode. \n\n**Quick Tips:**\n• PUBG Mobile: Direct character ID delivery usually takes under 30s.\n• Roblox/Steam gift cards: Redeem codes are instantly delivered to your email.\n• Payments are processed immediately in NPR via eSewa merchant accounts.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, fallbackMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadPresetQuery = (query: string) => {
    setInputMessage(query);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans">
      {/* Floating Sparkle Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 px-5 py-4 rounded-none bg-red-600 hover:bg-red-700 text-white font-mono font-black text-xs tracking-widest shadow-lg transition-all hover:translate-y-[-2px] active:translate-y-0 group relative overflow-hidden border-2 border-white"
          id="btn-chat-trigger"
        >
          <span className="relative z-10 flex items-center gap-2 uppercase">
            <Sparkles className="w-4 h-4 text-white shrink-0" />
            AI COMPANION
          </span>
          <span className="absolute right-1 top-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-red-600 animate-ping"></span>
        </button>
      )}

      {/* Slide Out Panel */}
      {isOpen && (
        <div
          className="w-80 sm:w-96 h-[500px] rounded-none bg-slate-900 border-2 border-slate-800 flex flex-col overflow-hidden shadow-2xl transition-all duration-300"
        >
          {/* Header */}
          <div className="p-4 bg-slate-950 border-b-2 border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-2.5 h-2.5 rounded-none bg-red-500 animate-pulse"></div>
              <div>
                <h3 className="text-sm font-black text-white tracking-widest uppercase font-display">AI GAME SYSTEM COMPANION</h3>
                <p className="text-[10px] text-red-400 font-mono uppercase tracking-widest">NEPAL SECURE GATEWAY HUB</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white hover:bg-red-600 hover:text-white p-1 rounded-none border border-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Info Bar */}
          <div className="bg-slate-950/85 px-4 py-2 border-b border-slate-800 flex items-center justify-between text-[10px] text-slate-400 font-mono uppercase tracking-wider">
            <span className="flex items-center gap-1"><Zap className="w-3 h-3 text-red-500" /> Automated answers active</span>
            <span className="text-emerald-400 font-black">NPR ledgers verified</span>
          </div>

          {/* Message List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-950/20">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.role !== 'user' && (
                  <div className="w-7 h-7 rounded-none bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0">
                    <Sparkles className="w-3.5 h-3.5 text-red-500" />
                  </div>
                )}
                <div
                  className={`max-w-[78%] rounded-none px-3.5 py-2.5 text-xs sm:text-[13px] leading-relaxed whitespace-pre-line ${
                    msg.role === 'user'
                      ? 'bg-red-600 text-white font-semibold'
                      : 'bg-slate-900 border border-slate-800 text-slate-200'
                  }`}
                >
                  {msg.content}
                </div>
                {msg.role === 'user' && (
                  <div className="w-7 h-7 rounded-none bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0">
                    <User className="w-3.5 h-3.5 text-red-500" />
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-2.5 justify-start">
                <div className="w-7 h-7 rounded-none bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0">
                  <Sparkles className="w-3.5 h-3.5 text-red-500 animate-spin" />
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-none px-4 py-3 flex items-center gap-1.5 text-[10px] font-mono text-slate-450 font-black tracking-widest">
                  <span className="w-1.5 h-1.5 bg-red-500 animate-bounce"></span>
                  <span className="w-1.5 h-1.5 bg-red-500 animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                  <span className="w-1.5 h-1.5 bg-red-500 animate-bounce" style={{ animationDelay: '0.4s' }}></span>
                  READING...
                </div>
              </div>
            )}

            {hasError && (
              <div className="flex gap-1.5 items-center justify-center text-[9px] text-red-500 font-mono bg-red-500/5 border border-red-500/20 py-2">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" /> API offline. Running in local mode.
              </div>
            )}
            
            <div ref={chatEndRef} />
          </div>

          {/* Quick suggestions */}
          <div className="px-4 py-2 border-t border-slate-800 bg-slate-950 flex items-center gap-1.5 overflow-x-auto scrollbar-hide text-[10px] font-mono font-black uppercase text-red-400">
            <span className="shrink-0 text-slate-500">PROMPTS:</span>
            <button
              onClick={() => loadPresetQuery("How to find PUBG character id?")}
              className="shrink-0 px-2.5 py-1 bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors"
            >
              PUBG ID
            </button>
            <button
              onClick={() => loadPresetQuery("Which voucher option has Robux?")}
              className="shrink-0 px-2.5 py-1 bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors"
            >
              Robux List
            </button>
            <button
              onClick={() => loadPresetQuery("How long does eSewa delivery take?")}
              className="shrink-0 px-2.5 py-1 bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors"
            >
              eSewa Speed
            </button>
          </div>

          {/* Input Area */}
          <form onSubmit={handleSendMessage} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Type your question..."
              className="flex-1 bg-slate-900 border border-slate-800 rounded-none px-3 py-2 text-xs text-white placeholder-slate-600 focus:border-red-500 transition-all font-mono"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim() || isLoading}
              className={`p-2.5 rounded-none flex items-center justify-center transition-all border-2 border-transparent ${
                inputMessage.trim() && !isLoading
                  ? 'bg-red-600 hover:bg-red-700 text-white'
                  : 'bg-slate-800 text-slate-600 cursor-not-allowed'
              }`}
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
