import React, { useState, useEffect } from 'react';
import { Activity, ShieldCheck, Zap, Server } from 'lucide-react';

interface FeedItem {
  id: string;
  user: string;
  productName: string;
  amount: string;
  paymentMethod: string;
  timeAgo: string;
}

const INITIAL_FEED: FeedItem[] = [
  { id: '1', user: '984***193', productName: 'PUBG Mobile UC', amount: '325 UC', paymentMethod: 'eSewa', timeAgo: '2s ago' },
  { id: '2', user: 'shre***@gmail.com', productName: 'Steam Gift Card', amount: '$10 Wallet', paymentMethod: 'Khalti', timeAgo: '24s ago' },
  { id: '3', user: '981***029', productName: 'Free Fire Diamonds', amount: '520 Diamonds', paymentMethod: 'IME Pay', timeAgo: '1m ago' },
  { id: '4', user: 'nira***@outlook.com', productName: 'Roblox Gift Card', amount: '2000 Robux', paymentMethod: 'Bank Transfer', timeAgo: '2m ago' },
  { id: '5', user: '980***884', productName: 'Valorant Points', amount: '1375 VP', paymentMethod: 'MyPay', timeAgo: '3m ago' }
];

const PRODUCT_NAMES = [
  { name: 'PUBG Mobile UC', amounts: ['60 UC', '325 UC', '660 UC', '1800 UC'] },
  { name: 'Free Fire Diamonds', amounts: ['100 Diamonds', '310 Diamonds', '520 Diamonds'] },
  { name: 'Valorant Points (VP)', amounts: ['125 VP', '420 VP', '700 VP'] },
  { name: 'Steam Wallet Gift Card', amounts: ['$5 Wallet', '$10 Wallet', '$20 Wallet'] },
  { name: 'Roblox Robux Gift Card', amounts: ['800 Robux', '2000 Robux'] },
  { name: 'Mobile Legends', amounts: ['86 Diamonds', '172 Diamonds', '257 Diamonds'] }
];

const NEPAL_PREFIXES = ['984***', '980***', '981***', '982***', '986***', '974***'];
const EMAIL_PFX = ['anup***', 'sush***', 'manish***', 'prakash***', 'kopila***', 'bimal***', 'prajwal***', 'aarav***'];
const EMAIL_DOMAINS = ['@gmail.com', '@hotmail.com', '@outlook.com', '@yahoo.com'];
const PAY_METHODS = ['eSewa', 'Khalti', 'IME Pay', 'MyPay', 'Bank Transfer'];

export default function LiveTransactionFeed() {
  const [feed, setFeed] = useState<FeedItem[]>(INITIAL_FEED);

  useEffect(() => {
    const interval = setInterval(() => {
      // Add new simulated transaction randomly
      const isPhone = Math.random() > 0.4;
      const user = isPhone 
        ? NEPAL_PREFIXES[Math.floor(Math.random() * NEPAL_PREFIXES.length)] + Math.floor(100 + Math.random() * 900)
        : EMAIL_PFX[Math.floor(Math.random() * EMAIL_PFX.length)] + EMAIL_DOMAINS[Math.floor(Math.random() * EMAIL_DOMAINS.length)];
      
      const prod = PRODUCT_NAMES[Math.floor(Math.random() * PRODUCT_NAMES.length)];
      const amount = prod.amounts[Math.floor(Math.random() * prod.amounts.length)];
      const paymentMethod = PAY_METHODS[Math.floor(Math.random() * PAY_METHODS.length)];

      const newItem: FeedItem = {
        id: Date.now().toString(),
        user,
        productName: prod.name,
        amount,
        paymentMethod,
        timeAgo: 'Just now'
      };

      setFeed(prev => {
        // Keep only top 5, updating timeAgo labels
        const updated = prev.map((item, index) => {
          if (item.timeAgo === 'Just now') return { ...item, timeAgo: '12s ago' };
          if (item.timeAgo === '2s ago') return { ...item, timeAgo: '32s ago' };
          if (item.timeAgo === '24s ago') return { ...item, timeAgo: '1m ago' };
          if (item.timeAgo.includes('s ago')) return { ...item, timeAgo: '2m ago' };
          if (item.timeAgo === '1m ago') return { ...item, timeAgo: '3m ago' };
          if (item.timeAgo === '2m ago') return { ...item, timeAgo: '5m ago' };
          return item;
        });
        return [newItem, ...updated.slice(0, 4)];
      });
    }, 9000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-slate-900 border-2 border-slate-800 rounded-none p-6 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/5 rounded-full blur-2xl pointer-events-none"></div>
      
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-3.5 border-b-2 border-slate-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-2.5 h-2.5 bg-red-500 animate-pulse shrink-0"></div>
          <h3 className="text-xl font-black tracking-tight text-white uppercase font-display">LIVE COMPLETED ORDERS</h3>
        </div>
        <div className="flex items-center gap-4 text-slate-400 text-[10px] font-mono uppercase tracking-widest leading-none">
          <span className="flex items-center gap-1.5"><Server className="w-3.5 h-3.5 text-slate-400" /> Server: Direct API</span>
          <span className="flex items-center gap-1 text-emerald-400"><ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> SSL Active</span>
        </div>
      </div>

      <div className="space-y-3.5">
        {feed.map((item) => (
          <div 
            key={item.id} 
            className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-4 bg-slate-950 border-l-4 border-red-600 hover:border-r-4 hover:border-red-600 transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-none bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0">
                <Zap className="w-4 h-4 text-red-500 group-hover:scale-110 transition-transform" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-slate-100 font-bold tracking-wider">{item.user}</span>
                  <span className="text-[9px] bg-emerald-500 text-black px-1.5 py-0.5 rounded-none font-mono font-bold tracking-wider">✓ INSTANT</span>
                </div>
                <p className="text-xs text-slate-400 font-medium tracking-wide mt-1">
                  Top-up: <span className="text-white font-black">{item.amount}</span> of <span className="text-red-400 font-bold uppercase">{item.productName}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between sm:justify-end gap-5">
              <div className="text-left sm:text-right">
                <span className="inline-block text-[10px] text-black bg-white px-2 py-0.5 rounded-none font-mono font-black tracking-widest uppercase">
                  {item.paymentMethod}
                </span>
                <p className="text-[10px] text-slate-500 font-mono tracking-wider text-right block mt-1">{item.timeAgo}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
