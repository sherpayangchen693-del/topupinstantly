import React, { useState, useEffect } from 'react';
import { Clock, RefreshCw, CheckCircle, Sliders, AlertTriangle, ChevronRight, CornerDownRight } from 'lucide-react';
import { Order } from '../types';

interface MyOrdersTrackerProps {
  orders: Order[];
  onClear: () => void;
}

export default function MyOrdersTracker({ orders, onClear }: MyOrdersTrackerProps) {
  // We keep a active mock progress map for any order that is not completed
  const [progression, setProgression] = useState<Record<string, { step: number; text: string }>>({});

  useEffect(() => {
    // Find orders that are in pending or processing state
    const activeOrders = orders.filter(o => o.status === 'pending' || o.status === 'processing');
    
    activeOrders.forEach(order => {
      if (progression[order.id]) return; // already tracking

      // Start a tick for this order
      let currentStep = 0;
      const steps = [
        { text: "Awaiting gateway payment broadcast..." },
        { text: "eSewa/Khalti transaction ID detected." },
        { text: "Securing character handshake on game node..." },
        { text: "Character verified safely. Fetching product catalog..." },
        { text: "Triggering API voucher distributor packets..." },
        { text: "Top-up success state response returned!" }
      ];

      const intervalId = setInterval(() => {
        if (currentStep < steps.length - 1) {
          currentStep++;
          setProgression(prev => ({
            ...prev,
            [order.id]: { step: currentStep, text: steps[currentStep].text }
          }));
        } else {
          clearInterval(intervalId);
          // Mark order as completed in local session!
          order.status = 'completed';
          setProgression(prev => {
            const updated = { ...prev };
            delete updated[order.id];
            return updated;
          });
        }
      }, 5000); // Progress every 5 seconds

      // Set initial
      setProgression(prev => ({
        ...prev,
        [order.id]: { step: 0, text: steps[0].text }
      }));
    });
  }, [orders]);

  if (orders.length === 0) return null;

  return (
    <div className="bg-slate-900 border-2 border-slate-800 rounded-none p-6 relative overflow-hidden" id="order-history-section">
      <div className="flex items-center justify-between mb-6 border-b-2 border-slate-800 pb-4">
        <div className="flex items-center gap-2.5">
          <Clock className="w-5 h-5 text-red-500" />
          <div>
            <h3 className="text-xl font-black tracking-tight text-white uppercase font-display">YOUR SESSION LEDGER</h3>
            <p className="text-[10px] text-slate-400 font-mono uppercase tracking-widest">SAVED LOCALLY ON DEVISE</p>
          </div>
        </div>
        <button 
          onClick={onClear}
          className="text-xs font-mono font-black tracking-widest text-red-500 hover:text-white bg-red-500/10 hover:bg-red-650 px-3 py-2 rounded-none border border-red-500/30 transition-all cursor-pointer uppercase"
        >
          WIPE ALL
        </button>
      </div>

      <div className="space-y-4">
        {orders.map((order) => {
          const isOngoing = order.status !== 'completed';
          const activeProgress = progression[order.id];
          const progressPercent = activeProgress ? Math.round(((activeProgress.step + 1) / 6) * 100) : 100;

          return (
            <div 
              key={order.id} 
              className="bg-slate-950 border-2 border-slate-800 rounded-none p-5"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3 mb-3.5">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs text-red-500 font-black tracking-wider">{order.id}</span>
                    <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-350 px-2 py-0.5 rounded-none font-mono">
                      {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <h4 className="text-base font-black tracking-tight text-white uppercase font-display mt-1">
                    {order.product.name} — <span className="text-red-400">{order.selectedTier.label}</span>
                  </h4>
                </div>

                <div className="text-left sm:text-right flex items-center sm:flex-col gap-2 justify-between">
                  {order.status === 'completed' ? (
                    <span className="inline-flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 border-2 border-emerald-500 px-2.5 py-1 rounded-none text-xs font-mono font-black tracking-wider uppercase">
                      <CheckCircle className="w-3.5 h-3.5" /> DELIVERED
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 bg-red-500/10 text-red-400 border-2 border-red-500 px-2.5 py-1 rounded-none text-xs font-mono font-black tracking-wider uppercase animate-pulse">
                      <RefreshCw className="w-3 h-3 animate-spin" /> DISPATCHING
                    </span>
                  )}
                  <span className="font-mono font-black text-emerald-400 text-lg block sm:mt-1">
                    NPR {order.selectedTier.price.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Character metadata */}
              <div className="space-y-1.5 text-xs font-mono tracking-wide text-slate-400 mb-3.5 bg-slate-900 border border-slate-800 rounded-none p-3.5">
                <div className="flex justify-between">
                  <span>Destination Target:</span>
                  <span className="font-mono text-white font-bold text-xs">{order.targetId}</span>
                </div>
                <div className="flex justify-between">
                  <span>Gateway Method:</span>
                  <span className="text-white font-bold">{order.paymentMethod.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Verification Class:</span>
                  <span className="text-red-400 font-bold">{order.product.requires}</span>
                </div>
              </div>

              {/* Progress Pipeline Visualization */}
              {isOngoing && activeProgress && (
                <div className="space-y-3 bg-slate-900 rounded-none p-4 border border-slate-800">
                  <div className="flex justify-between text-xs font-mono font-black uppercase">
                    <span className="text-red-400 flex items-center gap-1">
                      <Sliders className="w-3.5 h-3.5 text-red-500" /> Pipeline process
                    </span>
                    <span className="text-emerald-400">{progressPercent}% verified</span>
                  </div>
                  
                  {/* Progress bar */}
                  <div className="h-2 bg-slate-950 border border-slate-800 rounded-none overflow-hidden">
                    <div 
                      className="h-full bg-red-650 rounded-none transition-all duration-1000 ease-out" 
                      style={{ width: `${progressPercent}%`, backgroundColor: '#ef4444' }}
                    ></div>
                  </div>

                  <div className="flex items-start gap-1.5 text-[11px] text-slate-400 font-mono leading-relaxed mt-1">
                    <CornerDownRight className="w-3.5 h-3.5 shrink-0 text-red-500 mt-0.5" />
                    <div>
                      <span className="text-white font-bold">STATE: </span> 
                      <span className="text-slate-300 italic">{activeProgress.text}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Guide prompt */}
              {!isOngoing && (
                <div className="text-[10px] text-slate-500 font-mono italic flex items-center gap-1.5 mt-2">
                  <CheckCircle className="w-3 h-3 text-emerald-400 shrink-0" /> API broadcast packet complete. Vouchers injected.
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
