export interface Tier {
  label: string;
  price: number;
  originalPrice?: number;
}

export type ProductType = 'game' | 'giftcard';

export interface Product {
  id: number;
  name: string;
  type: ProductType;
  image: string;
  fallbackColor: string; // Tailwind gradient classes
  iconName: string;      // Lucide icon identifier
  tiers: Tier[];
  requires: string;      // e.g. "Player ID (UID)", "Email Address"
  placeholder: string;   // e.g. "e.g., 5512849102"
  tag: 'HOT' | 'NEW' | 'POPULAR' | '';
}

export interface PaymentMethod {
  id: string;
  name: string;
  bgGradient: string;
  iconName: string;
  accentColor: string;
  instructions: string;
  accountDetails?: {
    accountName: string;
    accountNumber: string;
    bankName?: string;
  };
}

export interface FAQItem {
  q: string;
  a: string;
}

export interface Order {
  id: string;
  product: Product;
  selectedTier: Tier;
  targetId: string; // Player ID or Email
  paymentMethod: PaymentMethod;
  paymentReceipt?: string; // Receipt file name or base64 representation
  status: 'pending' | 'processing' | 'completed' | 'failed';
  createdAt: string;
}
