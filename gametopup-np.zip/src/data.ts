import { Product, PaymentMethod, FAQItem } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 1,
    name: 'PUBG Mobile UC',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-amber-600 to-amber-900',
    iconName: 'Crosshair',
    tag: 'HOT',
    requires: 'Player ID (UID)',
    placeholder: 'e.g., 5518294025',
    tiers: [
      { label: '60 UC', price: 120, originalPrice: 150 },
      { label: '325 UC', price: 599, originalPrice: 650 },
      { label: '660 UC', price: 1150, originalPrice: 1250 },
      { label: '1800 UC', price: 2999, originalPrice: 3200 },
      { label: '3850 UC', price: 5999, originalPrice: 6500 },
      { label: '8100 UC', price: 11800, originalPrice: 13000 }
    ]
  },
  {
    id: 2,
    name: 'Free Fire Diamonds',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-red-600 to-orange-700',
    iconName: 'Flame',
    tag: 'HOT',
    requires: 'Player ID (UID)',
    placeholder: 'e.g., 782910482',
    tiers: [
      { label: '100 Diamonds', price: 95, originalPrice: 110 },
      { label: '310 Diamonds', price: 280, originalPrice: 310 },
      { label: '520 Diamonds', price: 460, originalPrice: 500 },
      { label: '1060 Diamonds', price: 920, originalPrice: 1000 },
      { label: '2180 Diamonds', price: 1850, originalPrice: 2000 }
    ]
  },
  {
    id: 3,
    name: 'Mobile Legends',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1612287230202-1bf1d85d1bdf?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-blue-600 to-indigo-900',
    iconName: 'Sword',
    tag: 'POPULAR',
    requires: 'User ID + Server ID',
    placeholder: 'e.g., 12345678 (1234)',
    tiers: [
      { label: '86 Diamonds', price: 135, originalPrice: 150 },
      { label: '172 Diamonds', price: 265, originalPrice: 290 },
      { label: '257 Diamonds', price: 395, originalPrice: 420 },
      { label: '344 Diamonds', price: 525, originalPrice: 570 },
      { label: '514 Diamonds', price: 780, originalPrice: 850 }
    ]
  },
  {
    id: 4,
    name: 'Genshin Impact Genesis',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-teal-600 to-blue-850',
    iconName: 'Sparkles',
    tag: 'POPULAR',
    requires: 'UID + Server Selection',
    placeholder: 'e.g., 812903481 (Asia)',
    tiers: [
      { label: '60 Genesis Crystals', price: 125, originalPrice: 140 },
      { label: '330 Genesis Crystals', price: 649, originalPrice: 700 },
      { label: '1090 Genesis Crystals', price: 2099, originalPrice: 2200 },
      { label: '2240 Genesis Crystals', price: 4199, originalPrice: 4500 }
    ]
  },
  {
    id: 5,
    name: 'Call of Duty Mobile CP',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-emerald-700 to-stone-800',
    iconName: 'Target',
    tag: '',
    requires: 'Player ID (UID)',
    placeholder: 'e.g., 68902402128934',
    tiers: [
      { label: '80 CP', price: 120, originalPrice: 135 },
      { label: '400 CP', price: 580, originalPrice: 620 },
      { label: '800 CP', price: 1120, originalPrice: 1200 },
      { label: '2000 CP', price: 2699, originalPrice: 2900 }
    ]
  },
  {
    id: 6,
    name: 'Valorant Points (VP)',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1560253023-3ec5d502959f?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-rose-600 to-pink-900',
    iconName: 'Gamepad2',
    tag: 'POPULAR',
    requires: 'Riot ID (Name#Tag)',
    placeholder: 'e.g., JettMain#NP1',
    tiers: [
      { label: '125 VP', price: 180, originalPrice: 200 },
      { label: '420 VP', price: 580, originalPrice: 650 },
      { label: '700 VP', price: 950, originalPrice: 1050 },
      { label: '1375 VP', price: 1850, originalPrice: 2000 }
    ]
  },
  {
    id: 7,
    name: 'Clash of Clans',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-yellow-600 to-amber-900',
    iconName: 'Shield',
    tag: '',
    requires: 'Player Tag (#)',
    placeholder: 'e.g., #9Y2V2QQG',
    tiers: [
      { label: '80 Gems + Gold Pass', price: 680, originalPrice: 750 },
      { label: '500 Gems', price: 560, originalPrice: 600 },
      { label: '1200 Gems', price: 1299, originalPrice: 1400 },
      { label: '2500 Gems', price: 2650, originalPrice: 2800 }
    ]
  },
  {
    id: 8,
    name: 'Fortnite V-Bucks',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1589241062272-c0a000072dfa?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-violet-700 to-indigo-950',
    iconName: 'Mountain',
    tag: '',
    requires: 'Epic Games Account ID',
    placeholder: 'e.g., ninja_nepal',
    tiers: [
      { label: '1000 V-Bucks', price: 950, originalPrice: 1100 },
      { label: '2800 V-Bucks', price: 2599, originalPrice: 2800 },
      { label: '5000 V-Bucks', price: 4499, originalPrice: 4900 }
    ]
  },
  {
    id: 9,
    name: 'Honkai Star Rail Oneiric',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1627856013091-fed6e4e30025?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-violet-800 to-pink-950',
    iconName: 'Rocket',
    tag: 'NEW',
    requires: 'UID + Server Selection',
    placeholder: 'e.g., 801329482 (Asia)',
    tiers: [
      { label: '60 Oneiric Shards', price: 125, originalPrice: 140 },
      { label: '330 Oneiric Shards', price: 649, originalPrice: 700 },
      { label: '1090 Oneiric Shards', price: 2099, originalPrice: 2200 },
      { label: '2240 Oneiric Shards', price: 4199, originalPrice: 4500 }
    ]
  },
  {
    id: 10,
    name: 'Apex Legends Coins',
    type: 'game',
    image: 'https://images.unsplash.com/photo-1553481187-be93c21490a9?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-red-600 to-stone-900',
    iconName: 'Activity',
    tag: '',
    requires: 'EA Account ID',
    placeholder: 'e.g., apex_legend_np',
    tiers: [
      { label: '1000 Coins', price: 950, originalPrice: 1050 },
      { label: '2150 Coins', price: 1999, originalPrice: 2200 },
      { label: '4350 Coins', price: 3999, originalPrice: 4200 }
    ]
  },

  // GIFT CARDS
  {
    id: 11,
    name: 'Steam Wallet Gift Card',
    type: 'giftcard',
    image: 'https://images.unsplash.com/photo-1580234810907-b40315b76418?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-slate-700 to-blue-950',
    iconName: 'Tv',
    tag: 'HOT',
    requires: 'Email Address for Code Delivery',
    placeholder: 'e.g., user@gmail.com',
    tiers: [
      { label: '$5 Steam Wallet', price: 680, originalPrice: 750 },
      { label: '$10 Steam Wallet', price: 1350, originalPrice: 1450 },
      { label: '$20 Steam Wallet', price: 2650, originalPrice: 2800 },
      { label: '$50 Steam Wallet', price: 6499, originalPrice: 6800 }
    ]
  },
  {
    id: 12,
    name: 'Roblox Robux Gift Card',
    type: 'giftcard',
    image: 'https://images.unsplash.com/photo-1566241477600-ac026ad43874?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-red-500 to-rose-950',
    iconName: 'Box',
    tag: 'POPULAR',
    requires: 'Email Address for Code Delivery',
    placeholder: 'e.g., player@gmail.com',
    tiers: [
      { label: '$10 Robux (800 Robux)', price: 1350, originalPrice: 1450 },
      { label: '$25 Robux (2000 Robux)', price: 3299, originalPrice: 3500 },
      { label: '$50 Robux (4500 Robux)', price: 6499, originalPrice: 6800 }
    ]
  },
  {
    id: 13,
    name: 'Google Play Gift Card (US)',
    type: 'giftcard',
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-emerald-500 to-sky-700',
    iconName: 'PlayCircle',
    tag: '',
    requires: 'Email Address for Code Delivery',
    placeholder: 'e.g., contact@gmail.com',
    tiers: [
      { label: '$10 Google Play US', price: 1350, originalPrice: 1450 },
      { label: '$25 Google Play US', price: 3299, originalPrice: 3500 },
      { label: '$50 Google Play US', price: 6499, originalPrice: 6800 }
    ]
  },
  {
    id: 14,
    name: 'PlayStation Store Gift Card',
    type: 'giftcard',
    image: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-blue-700 to-indigo-950',
    iconName: 'MonitorPlay',
    tag: '',
    requires: 'Email Address for Code Delivery',
    placeholder: 'e.g., play@gmail.com',
    tiers: [
      { label: '$10 PSN Card', price: 1380, originalPrice: 1500 },
      { label: '$25 PSN Card', price: 3350, originalPrice: 3600 },
      { label: '$50 PSN Card', price: 6550, originalPrice: 7000 }
    ]
  },
  {
    id: 15,
    name: 'Xbox Gift Card (US)',
    type: 'giftcard',
    image: 'https://images.unsplash.com/photo-1621259182978-f09e5e2cd091?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-green-600 to-green-950',
    iconName: 'Cpu',
    tag: '',
    requires: 'Email Address for Code Delivery',
    placeholder: 'e.g., xbox@gmail.com',
    tiers: [
      { label: '$15 Xbox Gift Card', price: 2050, originalPrice: 2200 },
      { label: '$25 Xbox Gift Card', price: 3350, originalPrice: 3600 },
      { label: '$50 Xbox Gift Card', price: 6550, originalPrice: 7000 }
    ]
  },
  {
    id: 16,
    name: 'Netflix Gift Card (US)',
    type: 'giftcard',
    image: 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-red-600 to-stone-950',
    iconName: 'Tv2',
    tag: 'NEW',
    requires: 'Email Address for Code Delivery',
    placeholder: 'e.g., cinema@gmail.com',
    tiers: [
      { label: '$15 Netflix US', price: 2050, originalPrice: 2200 },
      { label: '$30 Netflix US', price: 3999, originalPrice: 4250 },
      { label: '$60 Netflix US', price: 7899, originalPrice: 8300 }
    ]
  },
  {
    id: 17,
    name: 'Spotify Premium Gift Card',
    type: 'giftcard',
    image: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-green-500 to-emerald-950',
    iconName: 'Music',
    tag: '',
    requires: 'Email Address for Code Delivery',
    placeholder: 'e.g., musicfan@gmail.com',
    tiers: [
      { label: '1 Month Premium Support', price: 499, originalPrice: 550 },
      { label: '3 Months Premium Support', price: 1399, originalPrice: 1500 },
      { label: '6 Months Premium Support', price: 2699, originalPrice: 2900 }
    ]
  },
  {
    id: 18,
    name: 'Apple Gift Card (US)',
    type: 'giftcard',
    image: 'https://images.unsplash.com/photo-1563206767-5b18f218e8de?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-indigo-600 to-slate-900',
    iconName: 'Apple',
    tag: '',
    requires: 'Email Address for Code Delivery',
    placeholder: 'e.g., apple@gmail.com',
    tiers: [
      { label: '$10 Apple US', price: 1380, originalPrice: 1480 },
      { label: '$25 Apple US', price: 3350, originalPrice: 3550 },
      { label: '$50 Apple US', price: 6550, originalPrice: 6850 }
    ]
  },
  {
    id: 19,
    name: 'Discord Nitro Gift Card',
    type: 'giftcard',
    image: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-indigo-500 to-violet-950',
    iconName: 'MessageSquare',
    tag: '',
    requires: 'Email Address for Code Delivery',
    placeholder: 'e.g., client@gmail.com',
    tiers: [
      { label: '1 Month Nitro Boost', price: 699, originalPrice: 750 },
      { label: '1 Year Nitro Boost', price: 6999, originalPrice: 7500 }
    ]
  },
  {
    id: 20,
    name: 'Nintendo eShop Gift Card',
    type: 'giftcard',
    image: 'https://images.unsplash.com/photo-1595169004381-8e0f529a7be8?auto=format&fit=crop&q=80&w=600',
    fallbackColor: 'from-red-500 to-red-950',
    iconName: 'Gamepad',
    tag: '',
    requires: 'Email Address for Code Delivery',
    placeholder: 'e.g., nintendo@gmail.com',
    tiers: [
      { label: '$10 Nintendo Card', price: 1380, originalPrice: 1500 },
      { label: '$20 Nintendo Card', price: 2680, originalPrice: 2850 },
      { label: '$35 Nintendo Card', price: 4550, originalPrice: 4800 }
    ]
  }
];

export const PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: 'esewa',
    name: 'eSewa Wallet',
    bgGradient: 'from-emerald-500 via-green-600 to-emerald-700',
    iconName: 'Wallet',
    accentColor: '#10B981',
    instructions: 'Send the exact amount to our official eSewa Merchant ID or registered phone below. Ensure you include your Order ID in the payment remarks/notes.',
    accountDetails: {
      accountName: 'GameTopUp NP Systems',
      accountNumber: '9801234567'
    }
  },
  {
    id: 'khalti',
    name: 'Khalti Wallet',
    bgGradient: 'from-violet-500 via-purple-600 to-purple-800',
    iconName: 'Award',
    accentColor: '#8B5CF6',
    instructions: 'Transfer the exact amount to our official Khalti ID. Once processed, your order will trigger instantly.',
    accountDetails: {
      accountName: 'GameTopUp Nepal',
      accountNumber: '9845321098'
    }
  },
  {
    id: 'imepay',
    name: 'IME Pay Wallet',
    bgGradient: 'from-rose-500 via-red-600 to-rose-700',
    iconName: 'CreditCard',
    accentColor: '#F43F5E',
    instructions: 'Send the amount directly to our IME Pay wallet. Instant automated verification is supported.',
    accountDetails: {
      accountName: 'GameTopUp NP Inc.',
      accountNumber: '9812347654'
    }
  },
  {
    id: 'mypay',
    name: 'MyPay Nepal',
    bgGradient: 'from-orange-400 via-orange-500 to-amber-600',
    iconName: 'Smartphone',
    accentColor: '#F97316',
    instructions: 'Process raw wallet transfer using MyPay app to the recipient detail list below.',
    accountDetails: {
      accountName: 'GameTopUp NP Enterprises',
      accountNumber: '9808877665'
    }
  },
  {
    id: 'bank',
    name: 'Direct Bank Transfer',
    bgGradient: 'from-cyan-500 via-blue-600 to-indigo-700',
    iconName: 'Landmark',
    accentColor: '#06B6D4',
    instructions: 'Interbank transfer (IPS/ConnectIPS) to our Everest Bank / NIC Asia Account. Please load a clear receipt picture/screenshot in checkout to verify your payment status.',
    accountDetails: {
      accountName: 'GAMETOPUP NP SYSTEMS PVT LTD',
      accountNumber: '01201509348102',
      bankName: 'Everest Bank Ltd — Lazimpat Branch'
    }
  }
];

export const FAQS: FAQItem[] = [
  {
    q: 'Do I need to sign up or create an account to top up?',
    a: 'No! We maintain a strict no-signup policy. We appreciate your time. Just select your product, enter your Player UID / Email, pay with any local wallet (eSewa/Khalti, etc), and the top-up will be processed instantly.'
  },
  {
    q: 'Will you ever ask for my game login password?',
    a: 'No, absolutely never! Your account security is our maximum priority. We only require your Player ID / Character ID (UID) for game direct top-ups, and email addresses for digital gift card code deliveries. Never share your password with anyone.'
  },
  {
    q: 'How fast is the delivery process?',
    a: 'Our API integration with official game distributors is entirely automated. Once your payment is successfully detected (under standard seconds), delivery usually takes only 15 to 30 seconds! In peak hours, it might take up to 2-3 minutes max.'
  },
  {
    q: 'Which Nepali payment systems are supported?',
    a: 'We native-support eSewa, Khalti, IME Pay, MyPay and direct Bank Transfers (ConnectIPS/Interbank). No international cards or dollar accounts are needed!'
  },
  {
    q: 'What if I entered the wrong Character/Player ID?',
    a: 'Our automated system delivers the coins/points to the exact character ID provided in real time, which cannot be reversed. Please double-check your game username and Player ID inside your target application profile tab prior to submitting checkout.'
  },
  {
    q: 'Do I need to message someone on WhatsApp or Facebook to activate my top-up?',
    a: 'No! We do not require you to call or message any manual operator. Our web portal connects directly with verification processors to approve transfers and deliver immediately. You can sit back and watch your game wallet fill up!'
  }
];
