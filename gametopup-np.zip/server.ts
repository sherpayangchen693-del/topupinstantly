import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Initialize Express
const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini client safely with standard options
let ai: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini Client successfully initialized on backend.");
  } else {
    console.warn("WARN: GEMINI_API_KEY is not set in environment variables. Offline mock AI activated.");
  }
} catch (err) {
  console.error("Failed to initialize Gemini client:", err);
}

// Support chatbot system instruction
const SYSTEM_INSTRUCTION = `You are the GameTopUp NP AI Support Agent, the automated system helpful assistant for Nepal's leading automated game voucher & top-up platform.
Your demeanor is futuristic, incredibly fast, highly professional, polite, and reassuring.
Here is the core information you have about GameTopUp NP to help users:
1. SECURITY MANDATE: We NEVER ask for passwords. Only ever Character UID, Riot ID, or Email is requested. Your game account is 100% safe.
2. DELIVERY: 100% automated. Once payment is detected, top-ups/vouchers take 15-30 seconds to arrive in-game!
3. PAYMENT METHODS: eSewa, Khalti, IME Pay, MyPay, and interbank direct transfers. Users do not need any USD/international cards.
4. MAIN PRODUCTS: 
   - PUBG Mobile (vouchers 60 UC for 120 NPR, 325 UC for 599 NPR, 660 UC for 1150 NPR, up to 8100 UC)
   - Free Fire (vouchers 100 Diamonds for 95 NPR, 310 for 280 NPR, 520 for 460 NPR, up to 2180 Diamonds)
   - Valorant Points (VP) (125 VP for 180 NPR, 420 VP for 580 NPR, 700 VP for 950 NPR, 1375 VP for 1850 NPR)
   - Mobile Legends Diamonds, Genshin Impact Genesis Crystals, Call of Duty Mobile CP, Clash of Clans Gems, Fortnite V-Bucks, Honkai Star Rail Oneiric, Apex Legends Coins.
   - Gift Cards: Steam Wallet ($5 Card for 680 NPR, $10 for 1350 NPR, $25 for 3299 NPR), Roblox, Google Play US, PlayStation Store, Xbox, Netflix, Spotify Premium, Apple iTunes, Discord Nitro, and Nintendo eShop.
5. TROUBLESHOOTING:
   - "How do I find my PUBG Character ID?": Go to your PUBG Lobby, click your profile avatar at top-left. You will see a number like "5518294025" near your name. This is your Player ID!
   - "Where is my gift card code?": It is sent directly to the email address you entered during checkout instantly upon automated verification!
   - "My top-up has not arrived": Vouchers usually arrive in seconds! Please wait up to 3 minutes. If there is a delay, please provide your order ID (e.g. GTPXXXXXXXX) and contact human support at support@gametopupnp.com.

Rules of Interaction:
- Keep answers relatively concise and highly structured with bullet points.
- Always quote prices in NPR.
- Ensure the user understands that we DO NOT require receipts or WhatsApp contact for standard payments, although we provide the option to manually upload a receipt screenshot during bank transfer checkouts.
- When answering where a game is or how to do something, use precise directions.`;

// API routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Server is healthy and monitoring top-up packets" });
});

app.post("/api/support-chat", async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message) {
      return res.status(400).json({ error: "Message is required." });
    }

    if (!ai) {
      // Return a professional mock response if API Key is not set yet
      const lower = message.toLowerCase();
      let responseText = "Hello! I am your automated GameTopUp NP Support Assistant. ";
      
      if (lower.includes("pubg") || lower.includes("uc")) {
        responseText += "For PUBG Mobile, we support immediate top-ups from 60 UC (120 NPR) up to 8100 UC (11,800 NPR). No account passwords required, purely character ID! What amount are you interested in?";
      } else if (lower.includes("free fire") || lower.includes("diamond")) {
        responseText += "For Free Fire, packages range from 100 Diamonds (95 NPR) to 2180 Diamonds (1850 NPR). Just enter your UID at checkout, pay via eSewa/Khalti, and it arrives in 30 seconds!";
      } else if (lower.includes("steam") || lower.includes("card") || lower.includes("roblox")) {
        responseText += "Digital gift cards (Steam, Roblox, Google Play, Netflix, etc.) are delivered instantly as digital codes directly to the email address you mention. Prices are fully in NPR with zero hidden gateway fees!";
      } else if (lower.includes("pay") || lower.includes("esewa") || lower.includes("khalti") || lower.includes("bank")) {
        responseText += "We support eSewa, Khalti, IME Pay, MyPay and interbank direct bank transfers. No international cards needed to experience automated checkout!";
      } else if (lower.includes("id") || lower.includes("uid") || lower.includes("find")) {
        responseText += "To find your PUBG UID, tap your avatar in the main lobby; your UID is the number below your gaming tag. For other games, check your profile/settings page. Rest assured, we never ask for passwords!";
      } else {
        responseText += "I am ready 24/7 to help you with instant game top-ups (PUBG, Free Fire, Mobile Legends, Valorant) and gift cards in Nepal. Ask me any question!";
      }
      return res.json({ text: responseText, source: "mock-ai" });
    }

    // Adapt standard history structure to Gemini API format if sent
    const formattedContents: any[] = [];
    if (history && Array.isArray(history)) {
      history.slice(-6).forEach(h => {
        formattedContents.push({
          role: h.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: h.content }]
        });
      });
    }
    
    // Add current user prompt
    formattedContents.push({
      role: 'user',
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedContents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      }
    });

    res.json({ text: response.text || "I apologize, I could not generate a response. Please try again.", source: "gemini-ai" });

  } catch (error: any) {
    console.error("AI support assistant processing failed:", error);
    res.status(500).json({ error: "Top-up companion system experienced error. " + error.message });
  }
});

// Vite middleware configuration for full-stack
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development server is mounted as middleware.");
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[GameTopUp NP] full stack server is successfully listening on port ${PORT}`);
  });
}

startServer();
